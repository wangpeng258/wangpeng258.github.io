'use strict';(()=>{})(rea);
